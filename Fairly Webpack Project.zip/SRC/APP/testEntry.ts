﻿import { TestApp } from "./test";

const instance = new TestApp();
instance.run();
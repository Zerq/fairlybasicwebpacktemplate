﻿import "./test.html";
import "./StyleSheet.css";


export class TestApp {
    public run() {

        const img = require("./cat.jpg");

            const testDiv = document.getElementById("testDiv");
            testDiv.innerText = "hello world :3 ";

            const image = <HTMLImageElement>document.createElement("img");
            image.src = img;
            image.id = "test image";
            image.style.width = "300px";
            image.style.height = "300px";
            image.style.border = "solid 2px black";

            testDiv.appendChild(image);





    }
}
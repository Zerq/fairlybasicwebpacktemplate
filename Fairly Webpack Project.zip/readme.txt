﻿Super basic webpack template

program.cs contains 

app.MapGet("/", () =>  Results.File("~/test.html", "text/html"));
this maps the root of the app to the test.html page


in webpack.config.js

    the netry section has 
            test: { import: "./app/testEntry.ts" }
    this tells it that "test" relates to the testEntry.ts file


    in the plugin section it also has 

            new HtmlWebpackPlugin({
                template: "./app/test.html",
               chunks: ["test"],
                filename: "test.html"
            })
    which assosiates test  with the html so webpack knows what goes into what.


  the webpack is also set up so you TS files can import css files
  with a simple 

        import "style.css";

 in your Ts files